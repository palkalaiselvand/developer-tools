self.assetsManifest = {
  "version": "KKU8T2vS",
  "assets": [
    {
      "hash": "sha256-1K7h9KFAuXjdDHXsMhQVND18HGtPne5++wjZBzpSiOY=",
      "url": "DevTools.styles.css"
    },
    {
      "hash": "sha256-1CPZ9X4csRVM0ymz7VwAf29h7QWaK5lV6yXnhmcGBE8=",
      "url": "_content/BlazorMonaco/jsInterop.js"
    },
    {
      "hash": "sha256-N57so4eR2ON4Z4OgTGGEL3JwJm/ZPSFkQxLxIHl/WO4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/nls.messages.de.js.map"
    },
    {
      "hash": "sha256-F0etq8o3gIM7TJnqu+gdbC6LXeV5vl6yfFf0gRjq0n4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/nls.messages.es.js.map"
    },
    {
      "hash": "sha256-+5uQ8HXNhoHBVo1pwr4zsepGfRCZ9z/YC0uH1aj6Rb8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/nls.messages.fr.js.map"
    },
    {
      "hash": "sha256-HvDNo7ptoKOoU0/muKxnB2C6mypiNder81Heb5mZr7Y=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/nls.messages.it.js.map"
    },
    {
      "hash": "sha256-QH/EaYnaFrr2BT0dSxH3WACz4pEO8g4MRaamq+6s3Ys=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/nls.messages.ja.js.map"
    },
    {
      "hash": "sha256-G5UCB1oGeZXTbPl70TBc5s3oRISvsiXOpBnpejxQvd8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/nls.messages.ko.js.map"
    },
    {
      "hash": "sha256-QHxyd3T2B3kV52k/b91eTzQLojEKMaK3XNH71ysOOVI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/nls.messages.ru.js.map"
    },
    {
      "hash": "sha256-b2zxg8Zo7zwgyrwhP+kEl6uoM1WwnunXx6HQ3uU1hoA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/nls.messages.zh-cn.js.map"
    },
    {
      "hash": "sha256-AfAnqSgE/SPVK/QR52g+OlnO/sl4zQJe3mHftUrEtKk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/nls.messages.zh-tw.js.map"
    },
    {
      "hash": "sha256-21wV7Vl3z5u/Q0LUYroow8XgB2n9i/QHHYyU0K1/eqo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/base/worker/workerMain.js.map"
    },
    {
      "hash": "sha256-io2Co8JfWSpxhL28KTw8S1yYFlfBc5B6YvJlcpl1pzE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/editor/editor.main.js.map"
    },
    {
      "hash": "sha256-qcThK6rzrMl6ieDk9qrJDw/9xlqZmYEdRFjRQjNDcY0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min-maps/vs/loader.js.map"
    },
    {
      "hash": "sha256-Dx1SGZNOlug7jbFi1gtNjAm13h59OAMcuv5KPA8oick=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/browser/ui/codicons/codicon/codicon.ttf"
    },
    {
      "hash": "sha256-7vabPD09NYMnPM/Q8HyQWmtCh5ez42kUk3FFBTjVYk4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/base/worker/workerMain.js"
    },
    {
      "hash": "sha256-NajbkMjO7X7wLnKTyrU2Fvvupx7rIinstTcWc0zboEQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/abap/abap.js"
    },
    {
      "hash": "sha256-+T4kWmHO/wPIF9Go2M1fus/SEb/mBc6MNJBgASPGx04=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/abap/abap.min.js"
    },
    {
      "hash": "sha256-/Q+wLodt2sjBlhHrWD4fIbeG5Misku+3FpBQqoAKkiM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/apex/apex.js"
    },
    {
      "hash": "sha256-pw/JX/hG3w9Wtfs8HJS3Cx073A2G4P/PjmpcgZENiUY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/apex/apex.min.js"
    },
    {
      "hash": "sha256-n3in9DH8VRo8hKV7NOIbb7WuXl6CMhaL7eDuC6N+OvY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/azcli/azcli.js"
    },
    {
      "hash": "sha256-94aFLbhY4SGk3gyGjvItAZfB2WZXc6NqeauiGTJ4Sa4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/azcli/azcli.min.js"
    },
    {
      "hash": "sha256-4U/R7GP/hWOu9KGEANyBFnI4e27QnhH9hgTc08gyj8s=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/bat/bat.js"
    },
    {
      "hash": "sha256-iivD5kbC0sl2Shc/mcfJpbV9+km42EAMGJtum/nwqEY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/bat/bat.min.js"
    },
    {
      "hash": "sha256-BCG56Mt17+c4VpT1kGV38QQyocCZey/okwSVERqD7Jo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/bicep/bicep.js"
    },
    {
      "hash": "sha256-99cPP3Ofh4iqZ6jdTF4+g+RlM+ExDGEYA9p/NvlwUtg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/bicep/bicep.min.js"
    },
    {
      "hash": "sha256-M3lARdDpiqWJCH3fmvHZ5mqx1AHGIqNv5l1+ZjbjWq0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/cameligo/cameligo.js"
    },
    {
      "hash": "sha256-UxdQ6b0lZd/uRZgo8N0ymmAqPx8nz0zhHZqk0P2WORM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/cameligo/cameligo.min.js"
    },
    {
      "hash": "sha256-zd311hJA+Myt1JzyyeUoi0GnNHh9zXsb4kzONK18SBI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/clojure/clojure.js"
    },
    {
      "hash": "sha256-RR5xNG1KorpnXc2hEvv9ZDjTq9kR9w4rZ5tFXTe/4dk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/clojure/clojure.min.js"
    },
    {
      "hash": "sha256-Nh9W67IL0KQL1h9Ul678qZTWrNwXj7e5zZZEcDO1uIY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/coffee/coffee.js"
    },
    {
      "hash": "sha256-LrHh5di68gJJzCo9AO9ptd8CLn00lcET6T01TszIsLA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/coffee/coffee.min.js"
    },
    {
      "hash": "sha256-mu2+yc/Z1POosL2QXZsvMuR/GzsNVEIQ7OuNcTCmVqQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/cpp/cpp.js"
    },
    {
      "hash": "sha256-C9JTqBvlDAnDmXkaR2nUT1hXf3BE0RGbg0b4/EyzGl4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/cpp/cpp.min.js"
    },
    {
      "hash": "sha256-NUOnwVxSpoWf0/rKOZaiClVlcKAczfAqDE3wNn2/sFo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/csharp/csharp.js"
    },
    {
      "hash": "sha256-5UcAYujYA249JZUpfYjj5gw9TG892xUQlPRc8i4X+UA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/csharp/csharp.min.js"
    },
    {
      "hash": "sha256-AAuGIvd7t10IUHKuyHbdvP2n3E6hXn762HE+LfW6OL8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/csp/csp.js"
    },
    {
      "hash": "sha256-1Rg+flhv+v3LwmgY9Gc5yRPZwXNLg5V2r117KJSKMKE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/csp/csp.min.js"
    },
    {
      "hash": "sha256-b73lFK3VvGP7v6OkaXJt+CuUFSvmVIeFHjh6IRhXXtg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/css/css.js"
    },
    {
      "hash": "sha256-jzDLDnqG41k08I73G76UnWH4sT9G+qLXyCsUaSPVhCY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/css/css.min.js"
    },
    {
      "hash": "sha256-SqcgLS6ozluTT3M1oo4KHYn1DI6kmYR6NJv5OA6p6Kc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/cypher/cypher.js"
    },
    {
      "hash": "sha256-vK+wlaFjkEYiPi4XMNY7x/s3UWIk3/9Lezy7pWbloo0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/cypher/cypher.min.js"
    },
    {
      "hash": "sha256-tr4Nz8Wd5S1GPxqmE8pQFRO7avmJuMbVB2d4Y2HiPu8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/dart/dart.js"
    },
    {
      "hash": "sha256-Rsf4kwRIxikCQCdTY6w3+rJF1xz6+xPn3nbdYWY9os8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/dart/dart.min.js"
    },
    {
      "hash": "sha256-wr/VqNzXr9MsEA+XRw8xXIo99UgHZXGaj12aSq+KQcQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/dockerfile/dockerfile.js"
    },
    {
      "hash": "sha256-xE4SnpZCeXV5sNfTD+LUILWwJQ3YaiRy5qtiOYurUVc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/dockerfile/dockerfile.min.js"
    },
    {
      "hash": "sha256-eqaypegM4FcNnoOsstrT2p5Nx34Gy6TbDhD6ee/7RxM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/ecl/ecl.js"
    },
    {
      "hash": "sha256-T+JUWv5Ohq2Z0bT0KM+WO+mipR0wKmOc6KBazgKQoKM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/ecl/ecl.min.js"
    },
    {
      "hash": "sha256-kqEWdWU/DUZe0cBlly6oH/E0xRZiRe6hvdYv03OF6UU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/elixir/elixir.js"
    },
    {
      "hash": "sha256-KMq8Qh5CCXSPvcYPuLvTvzTLyvpCkaJ6CxKBbYdNDTI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/elixir/elixir.min.js"
    },
    {
      "hash": "sha256-CaxjOZgVDNEjkohhsFIcgviZn4RZv5zP1l79nildryQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/flow9/flow9.js"
    },
    {
      "hash": "sha256-5TY/LJFq/yaXR5XLfVfLU41izP1Wp3aM4Ab//9uo7Rk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/flow9/flow9.min.js"
    },
    {
      "hash": "sha256-yMntSLCnRAQ5qdop3ZMdLtYWPoMC7V0zUBGu76hfK+k=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/freemarker2/freemarker2.js"
    },
    {
      "hash": "sha256-2m9+sco55Wv9682IFGnlBTmM8K3MwAgFFPpmAfSrBUs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/freemarker2/freemarker2.min.js"
    },
    {
      "hash": "sha256-Pnwn+6AlK/i49P6P+FSg9rFg2/xr0vU6yTE1gb/rU5s=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/fsharp/fsharp.js"
    },
    {
      "hash": "sha256-+zB99crII7SsOpzjsr/LhpTOFG1kOR9Eb1kzkvd6jEs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/fsharp/fsharp.min.js"
    },
    {
      "hash": "sha256-rEW635xthL5GSbpiTK3zdWASiPHX8S9qPOKTwZ1rlEc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/go/go.js"
    },
    {
      "hash": "sha256-MY05rWlQIagO/A30+lII/mL/h6nQs4zZLzISdmDePaY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/go/go.min.js"
    },
    {
      "hash": "sha256-CXnP+OzGBljB5wtkRsaGCdpEKjkMV4MGWeC2MKXJjBk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/graphql/graphql.js"
    },
    {
      "hash": "sha256-eF6zu6Bx6oGmhqQI+3IEbpiYEa8DEJSOxHaVcg0lZIs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/graphql/graphql.min.js"
    },
    {
      "hash": "sha256-SzXXVSPpEEQZJCGK0CGzyAO8mJFY6xB8CczWNXkduLw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/handlebars/handlebars.js"
    },
    {
      "hash": "sha256-dPIjxsYAMrQP6rBWgNu7dS8f4N2JJJIXCiLjsarpKTY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/handlebars/handlebars.min.js"
    },
    {
      "hash": "sha256-JL6NWRkz04rrV6tyjWP2MrxcVwDEwxojDZlcXN79TXA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/hcl/hcl.js"
    },
    {
      "hash": "sha256-Pguh06L/v517EvMXCHoLo2jHxokCwI3b2cuN4829gr0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/hcl/hcl.min.js"
    },
    {
      "hash": "sha256-9zU8eRhLhCia4fekN5uy5PXCMC7tUoaD2z2dr0aC4n0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/html/html.js"
    },
    {
      "hash": "sha256-bCN0XECkmfQOSe6zO7WK/YJR4AsEpKqr41D6ePUb7KU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/html/html.min.js"
    },
    {
      "hash": "sha256-BLAKvU2n92OTVwAqvZv+Hs8BH67T1jckMv1UUUr+DeE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/ini/ini.js"
    },
    {
      "hash": "sha256-LBBQudCGB63g9QGs6IVv+wE3CVt5bQrhyBPTe4FlSgI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/ini/ini.min.js"
    },
    {
      "hash": "sha256-5SCF+yHpltRwHT5cKO15+rIcPlCwd1zBwfa7hdvIXGw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/java/java.js"
    },
    {
      "hash": "sha256-R0cfyvyQPnQzen7J53ZQdAfdsO1Fjj6oJmmoEpbFpFQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/java/java.min.js"
    },
    {
      "hash": "sha256-GOgyNwNHsNCpxmumxjdrpUPGTHlDtsSbjvUzo9FLk7A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/javascript/javascript.js"
    },
    {
      "hash": "sha256-bM+iQsCiXV7x0aHTt589MgiXFxGHipvjRlawaXX2LF0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/javascript/javascript.min.js"
    },
    {
      "hash": "sha256-82uoqF1jrARRLTYxgZTpMLFvI69RwrxAMzUUtiTMQCs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/julia/julia.js"
    },
    {
      "hash": "sha256-BpLtcpZgoquZHShHoOlSuiizVJrwmZujTCVrS6lz7kc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/julia/julia.min.js"
    },
    {
      "hash": "sha256-MeGKO5sEFjtN1Y9HLL7GTduAka8b4otweF/AjjWItE8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/kotlin/kotlin.js"
    },
    {
      "hash": "sha256-TuLx1nspNLMGv7kTDIo57k+L0kRCb7HxUTtvrCZEBXU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/kotlin/kotlin.min.js"
    },
    {
      "hash": "sha256-Dq8wgA+NYJ8GYRnatwP/2sifkRoWpiO67KOPFSW1Yns=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/less/less.js"
    },
    {
      "hash": "sha256-DSN2cSX1t74mMbhhBzWv9+k5bcKcism2bXbGc2ocgDk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/less/less.min.js"
    },
    {
      "hash": "sha256-0hSiOdPgM5wkc6xNOcPSVoJPUXDSxcdir2E64BWbF8I=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/lexon/lexon.js"
    },
    {
      "hash": "sha256-TnlfLyq11ZmCNe3DamazKHrc/QJIqHTyruhutJ7m5Qo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/lexon/lexon.min.js"
    },
    {
      "hash": "sha256-9iFXYicVti1L9CX69fYP/dcQutnYyDVM2ZRah4JR48w=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/liquid/liquid.js"
    },
    {
      "hash": "sha256-OmfnLy6CENNFZ2BklMW3eBRGVnAt5T0Nz6VjYNg7fEM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/liquid/liquid.min.js"
    },
    {
      "hash": "sha256-NS7pjn6PmdRe6h6Kxa9M/NgQZOOXD3ZXoiSRW9OLInA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/lua/lua.js"
    },
    {
      "hash": "sha256-NNZGzJX4xlqBMk8TQCd1XCcex/2wUeiIju+3Oav7xuA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/lua/lua.min.js"
    },
    {
      "hash": "sha256-Oo0zlboB/PQussnOGeczTosTYLJBV6ok4ogUFsXQhTc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/m3/m3.js"
    },
    {
      "hash": "sha256-kClu54F64ZiU1DbJdOztQQZTlPgUnV777oLPPEsEna0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/m3/m3.min.js"
    },
    {
      "hash": "sha256-2ADyzk40FnIvo+vfBm6W2b2V4VVTiBBIV/D7KXkms4k=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/markdown/markdown.js"
    },
    {
      "hash": "sha256-KBWXGjH7Ce8xX0XzAJRRnzI5NKIdC7fQjpXAbHLywKg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/markdown/markdown.min.js"
    },
    {
      "hash": "sha256-76cSrNNrv6F7NMFGAOAqCTkzxD7LVUrDCXV7IuEpO80=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/mdx/mdx.js"
    },
    {
      "hash": "sha256-ZXY1PpbqfYVA0IyOgTqhBeZWZlhqRYli3mao/bCSjuE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/mdx/mdx.min.js"
    },
    {
      "hash": "sha256-kp4WN6kbaoCLuDVJ89JLj5LTRdSdMgcc959B/h1DOQ4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/mips/mips.js"
    },
    {
      "hash": "sha256-yVowx5dKDGWKLDGh0ONJjFLmjykHcF6M6H+wL81kBHM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/mips/mips.min.js"
    },
    {
      "hash": "sha256-vadGk/RPp77BKBwmfhAZdDgKKIhTgJJGkNT+rUg9JvU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/msdax/msdax.js"
    },
    {
      "hash": "sha256-LXVlUFznbKjmqCJcwwO08GHpe3T69m2fZrjmUAgoYKA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/msdax/msdax.min.js"
    },
    {
      "hash": "sha256-g0rI4epokPOdRoCWNZ7mir/tHcHAW1yAv1WSpubR1Vc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/mysql/mysql.js"
    },
    {
      "hash": "sha256-PE5cRmwT7xkUFTXpXMx2+qvNCqmFN4snayt8iTDgtkg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/mysql/mysql.min.js"
    },
    {
      "hash": "sha256-B+z937hqCGAURCeJ3EjwNaIBrGGlU9gzZ2DR2/joYQs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/objective-c/objective-c.js"
    },
    {
      "hash": "sha256-Qg1HITcAT3wn16rNGVebNbO6dqkIf+gYXd6gMwO+IKU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/objective-c/objective-c.min.js"
    },
    {
      "hash": "sha256-ndHLbOEbtW/Us0sAXL0i1diVjfIxuA8AjeqVPv7a1Ew=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pascal/pascal.js"
    },
    {
      "hash": "sha256-o+6GvcLtiIXkt0w93p/nd7t+jFK9EQWoGR5P7DEHsFk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pascal/pascal.min.js"
    },
    {
      "hash": "sha256-FUigbuuSGxAvLibZqWax6fco740ieXshOCotoR8v6rg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pascaligo/pascaligo.js"
    },
    {
      "hash": "sha256-RmT0Y5eJxAz2avz45DsY/6zYsKZRS+NIglwuAxB1Wpc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pascaligo/pascaligo.min.js"
    },
    {
      "hash": "sha256-pzWUw8uIXuhKYVsgcYhLq3iI3De5M+aa70D0HGqVi58=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/perl/perl.js"
    },
    {
      "hash": "sha256-mfSYOf8zJjyQhxD/jvaWcVKtXjiMSHwLrxBtpGAYO2M=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/perl/perl.min.js"
    },
    {
      "hash": "sha256-zXCc9uvEvCZ0Rou0WWyKOOQZMvM4h4tjl5HQwqJ1wCQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pgsql/pgsql.js"
    },
    {
      "hash": "sha256-poWK5XY8t547d9lW3+KAg0wQdbMu+qmjoJLeulR5SgE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pgsql/pgsql.min.js"
    },
    {
      "hash": "sha256-ylsxPRr3qyTpgaCG/kpIZRUF+de/R4h1nNapYgD3tEo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/php/php.js"
    },
    {
      "hash": "sha256-bShj6DOd3dnq3qUjJiWHJsbYYdSK23m4wK4U1nOV6CU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/php/php.min.js"
    },
    {
      "hash": "sha256-PXjp3QlDMXhYs4X+vw2S9sQfNmes3GEDSvuhNfOvDOk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pla/pla.js"
    },
    {
      "hash": "sha256-pLhuL6KAO3SMo8mn4oDj7O13dXpn65C/TOCC3Q+slcM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pla/pla.min.js"
    },
    {
      "hash": "sha256-UVGL6cqiU/nc2p6LpWQ3YVLSZMfkbPEgFepbkg7xtUM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/postiats/postiats.js"
    },
    {
      "hash": "sha256-mptYA8e0VbLZEa+EB64779XTpK5I2OcjfOZqNC/OLWA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/postiats/postiats.min.js"
    },
    {
      "hash": "sha256-auP11FCvN1gYrKy6Ycm5asgj2AZjSM5D9n7O1fPY6zM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/powerquery/powerquery.js"
    },
    {
      "hash": "sha256-l2Vu9w3NCZ1+vAKJt5HSyMi91/k7W7maDtmajYmJzm4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/powerquery/powerquery.min.js"
    },
    {
      "hash": "sha256-gltoWmpHP4XKWhiWdn/VPt3XuivAnOE6rWE2/dkOmVo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/powershell/powershell.js"
    },
    {
      "hash": "sha256-9bQzEmSkdRVLNBqY69j/qVGQ3t9sQogxKJLEhdniSUI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/powershell/powershell.min.js"
    },
    {
      "hash": "sha256-5S4KZIfk4zPy3fEmnwLLZtntYKQmnd/JCPNrOrquSDo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/protobuf/protobuf.js"
    },
    {
      "hash": "sha256-Gyjvigw96/EZIYEOvXI4S8tQRvkEd3vN5W8OZk409k4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/protobuf/protobuf.min.js"
    },
    {
      "hash": "sha256-TuEmUQCVE2rhdkWJOeguH3tz3SFriwVVsE5zJ6JLHm0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pug/pug.js"
    },
    {
      "hash": "sha256-tfRYwJBeS1IOUcXsgRuaeRD4IsmKFZW9vn6cUFruemo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/pug/pug.min.js"
    },
    {
      "hash": "sha256-eFBvhJKR/j0uzIj/mJ8upB2TJCiEJXZ1AqyepBjhw2M=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/python/python.js"
    },
    {
      "hash": "sha256-Tc/Gk2+X1pvI9jH+hIsycYPHkCrgZYdmEdfcOac3XK8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/python/python.min.js"
    },
    {
      "hash": "sha256-X0NoGyXIAABLW/AetLccs8YP61jE6AWKQIidUVTOsAQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/qsharp/qsharp.js"
    },
    {
      "hash": "sha256-qR/nKuLZOT9SJHGipYQxzEqanqH+1yPNAc+qhGrKf8I=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/qsharp/qsharp.min.js"
    },
    {
      "hash": "sha256-uQY6kDhslRDokpHiDgO3GgPWsY38wOuPqE0YylVc4NQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/r/r.js"
    },
    {
      "hash": "sha256-qxYtk/YAxRX6bmRAzmtvODGExZnnTGsKOCu0PpiNZZI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/r/r.min.js"
    },
    {
      "hash": "sha256-twhAe6RrBQprSVbR37JbP+q9wNiFbszpyVqorIEJQZk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/razor/razor.js"
    },
    {
      "hash": "sha256-BIcH2PSa+qjOJ6SgBBsMyV/ywN1Q3WGAuA7B7CqDDmw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/razor/razor.min.js"
    },
    {
      "hash": "sha256-EY1b+Y18NWIGdE1jw0iT0K358pSP6MBrQcDuhOn37w4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/redis/redis.js"
    },
    {
      "hash": "sha256-p4CJuQti3GuhT6uup47o79ZXfLkddZhMwDKxY077CS8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/redis/redis.min.js"
    },
    {
      "hash": "sha256-jGd39DCNtC1uYIUYPc7GY3SCck9dfLrI/lslDI0IwDk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/redshift/redshift.js"
    },
    {
      "hash": "sha256-8mYe0QaH6WQKGf6/sTS1zxrcCz6hndS7Sfmx3rqGXzE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/redshift/redshift.min.js"
    },
    {
      "hash": "sha256-Ui7p9X50Yys0D+057Bq5vzksJYXtj3TmrbpKUZjr3L8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/restructuredtext/restructuredtext.js"
    },
    {
      "hash": "sha256-RJ8kJC80s8atDJJat9InM/aPb2+4KMVp6QC0nCQlfao=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/restructuredtext/restructuredtext.min.js"
    },
    {
      "hash": "sha256-jEyG5po1XLbDEL7EnCnhlFg09GQ6mCp1Fjrm7tqiLNo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/ruby/ruby.js"
    },
    {
      "hash": "sha256-7e0wEYLgPouk1R2trsn+00i15Jl2o9DZbGNuTg1Ke5A=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/ruby/ruby.min.js"
    },
    {
      "hash": "sha256-rLqD/nUFPHaTyglrEiG/Ny7j2PbWURPIcQBvcpwz7NU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/rust/rust.js"
    },
    {
      "hash": "sha256-ji2H7bmW1Vzq4sUK3Ocw9/y+55jpvzH77O9mWAtH5t8=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/rust/rust.min.js"
    },
    {
      "hash": "sha256-Y0J9CYx/kmErhvPz8NGanhx62XFNInaKfkooMMVBsok=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sb/sb.js"
    },
    {
      "hash": "sha256-+bxJMza+rBY4lv0PGXD3VUifawzN0f7/iP+RkBNSEC0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sb/sb.min.js"
    },
    {
      "hash": "sha256-U7MB4hSQkcetR2gXNHWwcx9AZtkFwT65S2ZFdkL/A/Q=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/scala/scala.js"
    },
    {
      "hash": "sha256-ubHILxXZaPJwyvZiVqoVwYFkWwcbx/4Uu/f2Fy9SCgg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/scala/scala.min.js"
    },
    {
      "hash": "sha256-gsJ4sI6DEuUN2OrSCoQGZCHV756e0+fExMQ1tHhV264=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/scheme/scheme.js"
    },
    {
      "hash": "sha256-cBBtJ2LaUEQDlYcQCOFGBbIxgAbSaXcoGagJx8vv/rM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/scheme/scheme.min.js"
    },
    {
      "hash": "sha256-ZfY6++6v9KHAmh3JhQ9LpCWFfYU+DtUD5UmtrIvO1XA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/scss/scss.js"
    },
    {
      "hash": "sha256-4vb0mu+/poIZRAlNlcAI9UAYidZar3g4FjK71/W2USI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/scss/scss.min.js"
    },
    {
      "hash": "sha256-D6JyARyZtUbpKnBrCDQNeuYS7YVCOJjwKrfah1sfxxg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/shell/shell.js"
    },
    {
      "hash": "sha256-+Aprl8W6Yvxl19bb6TrmC7Dgz118VP1KOh/FYWwKwzQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/shell/shell.min.js"
    },
    {
      "hash": "sha256-IAgsIJ3JWnT4LrH7inE86Om2znxEL+Ir55XH+g8c2Ls=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/solidity/solidity.js"
    },
    {
      "hash": "sha256-w68unfLT6hzy0TD19+zKXvXgOCEemz3eXlQz1PUeT0s=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/solidity/solidity.min.js"
    },
    {
      "hash": "sha256-3pE6wK+6OucA9CAEyMz3V0a1FAWs2GPvRfZuW+C4zY0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sophia/sophia.js"
    },
    {
      "hash": "sha256-8AZ01NhXFWAKYm4TE/OoCqiimIyMtVdd4Z1EOoVonQw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sophia/sophia.min.js"
    },
    {
      "hash": "sha256-V+zpmkCu32YUv+2x0b43n8zqsxPW83ue6DTaVj/YuvM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sparql/sparql.js"
    },
    {
      "hash": "sha256-qAHt5jz6YjCjn1DGMQRd3kde9YWWFS5EOpq/T7pX7Ic=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sparql/sparql.min.js"
    },
    {
      "hash": "sha256-5qTbtUIzEz90tbiolWKA2EVnAb37jd7N3yuiyQjIaEE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sql/sql.js"
    },
    {
      "hash": "sha256-n+SQuV/ty62FqGwp2dNXou/50mKyLyJlh5MX+A0M1MY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/sql/sql.min.js"
    },
    {
      "hash": "sha256-SBro0L1BrCZ07KN5dKRP5F/rhKoiXpDF4GukPLX+SI4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/st/st.js"
    },
    {
      "hash": "sha256-TQ8X2wkHYRabm37fcJhKW1EPVDUvEsxSa84GFTa4X8M=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/st/st.min.js"
    },
    {
      "hash": "sha256-x5/U0B1OaTFJPuLTmXOT5N6e0M0OwSc3BR0jVAu3Fo0=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/swift/swift.js"
    },
    {
      "hash": "sha256-jZIpq4KHIu2NKxMsKA4ZIE+M1EQi12PCmVzuBSArJDY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/swift/swift.min.js"
    },
    {
      "hash": "sha256-m4jJYHiUDlFIQgp9ICFDbUexV64HCiZSQG1p5ioIyXM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/systemverilog/systemverilog.js"
    },
    {
      "hash": "sha256-YlKz9vHdgfh+scJVCJNKv7sP9Yfiezjx6aeEZjn10vM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/systemverilog/systemverilog.min.js"
    },
    {
      "hash": "sha256-tiOPY+7kKhvPFtZ9h94qjsw1yh2tc2qmrgxuFZ3bi78=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/tcl/tcl.js"
    },
    {
      "hash": "sha256-ClchEv9Ol3GVhy8d8b+vQTN2CnM60+R7f4W7xsW1kzQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/tcl/tcl.min.js"
    },
    {
      "hash": "sha256-OswvLGuCNwo9DItecIWxN5Vj/3hjoz/zBDOErvvVSwg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/twig/twig.js"
    },
    {
      "hash": "sha256-hEFYtyFLvOPLx179NVCOKdidZxja1jVX2b3Sekkn5XQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/twig/twig.min.js"
    },
    {
      "hash": "sha256-TgoKZbxuXTWK3zDkM05BIz/VbuBGdJycXXBxbWpv11E=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/typescript/typescript.js"
    },
    {
      "hash": "sha256-YHyZmTl6Ul9ZK8AHDCqtMAXiLAWqrO7Ax5YqcU1ZJio=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/typescript/typescript.min.js"
    },
    {
      "hash": "sha256-Z2THPmS0O4iOng8rmLGqWXb4/k5Qld/N+Ny2mGf2ZAU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/typespec/typespec.js"
    },
    {
      "hash": "sha256-8nZs+DRwNOUjcNS1Lk+cTOrDo+tWSn76dfeiWan6BLk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/typespec/typespec.min.js"
    },
    {
      "hash": "sha256-zqpQOCzOb65IjpV0rEhwI8r0TrSh5p+PXv6Bd2yWqhA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/vb/vb.js"
    },
    {
      "hash": "sha256-4+SibikyGOUDarmouutz2j/mIfcwe1fIoGxmTdxNWo4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/vb/vb.min.js"
    },
    {
      "hash": "sha256-cmYJ4DHdLJQPd8EhUkQgaTCrTo4ywsp5jhK00vhqKbg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/wgsl/wgsl.js"
    },
    {
      "hash": "sha256-QJwfzosJFoVCThBN8hz6+7KDLgoS76p652UBsoV4cQY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/wgsl/wgsl.min.js"
    },
    {
      "hash": "sha256-PsggTcDyvsqY8+3mYI8WQGKxd1E2IicTh0B+WVnc0gU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/xml/xml.js"
    },
    {
      "hash": "sha256-x/AoisVk9y6G7IFxQFsVkSyY3A+jk1+Jxfc8YkqkMio=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/xml/xml.min.js"
    },
    {
      "hash": "sha256-B2A2cSQW6z8qK2MYVLqYl/gAYp+awvA1U9CAvzgl6UU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/yaml/yaml.js"
    },
    {
      "hash": "sha256-BvkPYc2mX65ZZuO1m91ojLajutiMu4BreSAgUfbE9sw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/basic-languages/yaml/yaml.min.js"
    },
    {
      "hash": "sha256-LFlDWVt+WUQe+BA4QzvZFa7xxShkuDO3RUnd2NMZqck=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.css"
    },
    {
      "hash": "sha256-oOke19ceRcSrBR+s1rpEarDPhkVRXAGAKxIIu39S6lg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.js"
    },
    {
      "hash": "sha256-ZHVFSlQCjB4m0rdzQ+sejHPhwu/o4qtyQfXKakAYZ8g=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/editor/editor.main.min.css"
    },
    {
      "hash": "sha256-26YDwFGGJwh00x1cCZF5kmJewX5stqMPQixa+FEGfkc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/css/cssMode.js"
    },
    {
      "hash": "sha256-dP9ylQPriofORiNcjn8/gC8l98fSHrvB8gxqtX3t+sE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/css/cssMode.min.js"
    },
    {
      "hash": "sha256-5NGXVp0QN5UVGL5GYY8rq0oJCqN0EYqw4XubZGn9dbc=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/css/cssWorker.js"
    },
    {
      "hash": "sha256-u0X1rE/Yb0MYO+TG+pm5Ql8xZcYCdltQ6GWsSFsOaAU=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/css/cssWorker.min.js"
    },
    {
      "hash": "sha256-XPu9Kb/AOXSBeuzh7UfBXDqOBYsU9e5q5jnl+gmld4c=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/html/htmlMode.js"
    },
    {
      "hash": "sha256-uhkzPTkSQR/JdRmOd1cN0woE8ATORaOyp4oSU7O2vLw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/html/htmlMode.min.js"
    },
    {
      "hash": "sha256-vQGWBdXTIZjc0n4D32en/l0JAMgIrExtLP/o3EXkExo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/html/htmlWorker.js"
    },
    {
      "hash": "sha256-xZatVCQDuYlcBUYn7TOSJWPgW9NUPgaa1OMvAugClyQ=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/html/htmlWorker.min.js"
    },
    {
      "hash": "sha256-UtZ9rmERymq3n/1dumpe/FfXwS+ReTzzqrSJrxEPvOw=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/json/jsonMode.js"
    },
    {
      "hash": "sha256-YZa0HMtx9I7mz1X3mHrUUtdwqY4a7T2vOo1telYmuxo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/json/jsonMode.min.js"
    },
    {
      "hash": "sha256-sACh5V0z08HAaDkT2hsY4MlVLZA2k/0Lx4uktuvC8aY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/json/jsonWorker.js"
    },
    {
      "hash": "sha256-Ej+hmF74aKbg6xxWfkwWZq2OCE/QUzxT5E0IcJvHQmk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/json/jsonWorker.min.js"
    },
    {
      "hash": "sha256-Hxd9U6CjCmBeM5K+V5JoC1pnL0eJRxP3qS77R+xLmRY=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/typescript/tsMode.js"
    },
    {
      "hash": "sha256-BttqpcKlrpBewX4bki2fBGMor8aKgc2rM9leUx5WpiI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/typescript/tsWorker.js"
    },
    {
      "hash": "sha256-PM6V8OzvTokhlVL23CAMECrFof8HBBpY0QFAbLJhfVo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/language/typescript/tsWorker.min.js"
    },
    {
      "hash": "sha256-5U7TTfYgRq7kELC2Cuvm0ykMHIf3NNQvUQY+Hq1e6H4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/loader.js"
    },
    {
      "hash": "sha256-wFbg/F3j6zkWoaNI9xK12ep13LuOzdj56TiqgRy2jFA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/loader.min.js"
    },
    {
      "hash": "sha256-PzFBJOB+I8fLL6G99jZ9cERN6fm+GJfFRt/EpAR0C/o=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.de.js"
    },
    {
      "hash": "sha256-bm7AJARdTwrA5NOm8BUI/h+arTmEAplDkyKIE7LONmA=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.de.min.js"
    },
    {
      "hash": "sha256-clymMsE3GAnoJZGTkUVRpU08CHadvL2txnacEGiAxks=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.es.js"
    },
    {
      "hash": "sha256-ufh1/VkyFfJPZcL1kTqsziEKp4z3tZ2Pghc5WJICw5s=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.es.min.js"
    },
    {
      "hash": "sha256-VdcVZPbE0s1v6z3MxqVfdQsP8RukOpoCa4TUvvuZfKk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.fr.js"
    },
    {
      "hash": "sha256-xKon5NoIR9ew1D9qhNY6X+zpVUtByzJ9gNDO7kI8hwo=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.fr.min.js"
    },
    {
      "hash": "sha256-cqSf64R95+5tNKSparLMlX8u1H2nOJGGTpayJsFKWSE=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.it.js"
    },
    {
      "hash": "sha256-WLDrUc8sJvqycXwuHN8fZW4LuMPurxVCom+8vu3EYz4=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.it.min.js"
    },
    {
      "hash": "sha256-LVN/Rx7PsUqVlrDIJQ59LEjmwDYsDUpnLg2vIrPsZ38=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.ja.js"
    },
    {
      "hash": "sha256-6qUzRC4S+xRShWEn2fJhRMtX2Jf0Z4eXlMDnio5jQfs=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.ja.min.js"
    },
    {
      "hash": "sha256-L5OlcBO997GeLavOfUItEqPgHZCuqyji1YZQZ1YITwg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.ko.js"
    },
    {
      "hash": "sha256-xSLPZYbORXMHQGC4IsMGZmTH+T4ri5GRSfBzGaCDXWg=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.ko.min.js"
    },
    {
      "hash": "sha256-2MyMtkLqweXN6prx9Qc66H4C5bjiYD2V+3xfQJne25U=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.ru.js"
    },
    {
      "hash": "sha256-ownbK9eRFN2QayVVtb44z5XNNvnhmB+JwmIHEywR9GM=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.ru.min.js"
    },
    {
      "hash": "sha256-UHMNajypcThbYn3YITkBRaPHZXzzq/L9bxUnCr+/NxI=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.zh-cn.js"
    },
    {
      "hash": "sha256-7/G+iYzxo3ARx+XzjAFhTUSfrRkvvRrDYRKEom+TDwk=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.zh-cn.min.js"
    },
    {
      "hash": "sha256-JT2lTLR69cIOqdlOF5EJgbHISppEUOHL8X8npybvk8I=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.zh-tw.js"
    },
    {
      "hash": "sha256-ZNL8HwEgyfI6ygNDyrjbRr4MAURyR32SrkHwMUXP49I=",
      "url": "_content/BlazorMonaco/lib/monaco-editor/min/vs/nls.messages.zh-tw.min.js"
    },
    {
      "hash": "sha256-LvYzL5DdU2cB0aD0vdq7fb6O1CcuZvp3OxCq/HCckhk=",
      "url": "_framework/BlazorMonaco.i33mlyw1st.wasm"
    },
    {
      "hash": "sha256-x3wNBUmbuUxc9DO2xYwqtsoCcsv5LNlu78aC5Vivg/0=",
      "url": "_framework/DevTools.7clvz7c7nz.wasm"
    },
    {
      "hash": "sha256-IeFoTML5Y+08HUO7Y/EzCm+FA6ElP6xk2BCusOjNF9Y=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.horg9ede60.wasm"
    },
    {
      "hash": "sha256-K4H030gkTHmaCEJlY5dOMaLEJ7KcGQRM+DuB3mH4L1A=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.di87cb8hf5.wasm"
    },
    {
      "hash": "sha256-jOjeJSgSy/S1qCSzaJBdzxnCpPkseNWVBqoj1ZHL0jI=",
      "url": "_framework/Microsoft.AspNetCore.Components.s68khoiaep.wasm"
    },
    {
      "hash": "sha256-vZf6U9oDQkyo0wHgUKt4AN1gzgKVnY9uENvmliMMqg0=",
      "url": "_framework/Microsoft.CSharp.3cxqlqeayc.wasm"
    },
    {
      "hash": "sha256-O/18yK/3Pj3wG2PLVJBN283TmIjoQ5k/JAdb5d/O+P8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.h19gpugiy5.wasm"
    },
    {
      "hash": "sha256-7Wv00KMrZAHb5sX5acrBZ6dNoPfDuaNWlT69VNMGt1g=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.n3x20s9cxz.wasm"
    },
    {
      "hash": "sha256-XhpSYR8F8A+kKAi/mojMfR/OreGPs3bc2GIu2PE9098=",
      "url": "_framework/Microsoft.Extensions.Configuration.icatoxhjsq.wasm"
    },
    {
      "hash": "sha256-Hrb70VDiZOU1O8PUbxcugPp9HeVNRjcXl9MHTL6/cew=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.a1zvfxqjfo.wasm"
    },
    {
      "hash": "sha256-DnnRKy8PZBHtfhziO6DfIwoozcHbfQiGwcXDh5nRSZc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.qeizni4cln.wasm"
    },
    {
      "hash": "sha256-WijGiJNaX6qnL+mrvvm4JS6cejxOl1gaW3tRxlPAMJA=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.qrkymho8xv.wasm"
    },
    {
      "hash": "sha256-TusUfPjSxh0GzZINX/Xk9afg45BQccmXJOyvulCHlU4=",
      "url": "_framework/Microsoft.Extensions.Logging.e47xhy91y6.wasm"
    },
    {
      "hash": "sha256-d+OJ34uR77eje6ACMKjKWXCBGqHtE0pTLB9vzpuYdH4=",
      "url": "_framework/Microsoft.Extensions.Options.dvulh3voq4.wasm"
    },
    {
      "hash": "sha256-6cQKFBXogCgICQbWptUlzgW+xOHIWbUMRjFxztqytdA=",
      "url": "_framework/Microsoft.Extensions.Primitives.9kx4ehp8td.wasm"
    },
    {
      "hash": "sha256-NNwR0xu2wKvvEIZnSUwKht+/0RJ9ziHW01M66VViIkI=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.s0bw0921jm.wasm"
    },
    {
      "hash": "sha256-XKYdndgfChvRApHX9srcHDwFlU47PgUGEu6JdEwmajI=",
      "url": "_framework/Microsoft.JSInterop.ceii4uvike.wasm"
    },
    {
      "hash": "sha256-3y1thJesChYq8FDb1x+q/EF3nLkv8b/y+cAa2pI93GQ=",
      "url": "_framework/NSQLFormatter.Standard.fk4fdnwiyr.wasm"
    },
    {
      "hash": "sha256-GlXMWKvDs45M2pACoR3Y4Qh8mcrOZGljqmvJY+6JZ5s=",
      "url": "_framework/Newtonsoft.Json.qkbufwhni2.wasm"
    },
    {
      "hash": "sha256-xMF0eauQ5DkSzUozHLFFMQnL6DSJO09nJLtgag+Dzbw=",
      "url": "_framework/System.8rv0tdtrxz.wasm"
    },
    {
      "hash": "sha256-MMH2Ok7oa22MNpgu6UU0ebv0YJjfymCWmjN7P38E7Do=",
      "url": "_framework/System.Collections.8ela8zkwvn.wasm"
    },
    {
      "hash": "sha256-Cv9DpY8Hq+rKo48wVhBHPiv1Ehe6DAd7NCQpK7o2how=",
      "url": "_framework/System.Collections.Concurrent.a7fo2fwfo2.wasm"
    },
    {
      "hash": "sha256-bqQtji52X8+5rzyiHJ7KzFwIqO3m+UY9HvFX8mlhQ34=",
      "url": "_framework/System.Collections.Immutable.e9sygaaebn.wasm"
    },
    {
      "hash": "sha256-Vv/LckSVxAb7KEfUD8Uw04N/Mw8bqj7Bd9LwBatCDic=",
      "url": "_framework/System.Collections.NonGeneric.qgxhxr3g9k.wasm"
    },
    {
      "hash": "sha256-EChlyAvnS1WyfLRr/D8EUziI+nGm9x25XxhSO1NW1UQ=",
      "url": "_framework/System.Collections.Specialized.o60wf0qwob.wasm"
    },
    {
      "hash": "sha256-XVc3qc06W+dW64jMUPr58ycZUEOhwuT73akKEpjWabI=",
      "url": "_framework/System.ComponentModel.Primitives.dof4znztm7.wasm"
    },
    {
      "hash": "sha256-GdVziYlhi32KnyXJk1CgOcDTz0PcQ9GSuLMSbMXD/Mk=",
      "url": "_framework/System.ComponentModel.TypeConverter.3tptfd05lo.wasm"
    },
    {
      "hash": "sha256-pYLaBeWMzy5oE2tWeKNL/PMnam15+r4QjbORp+HRYME=",
      "url": "_framework/System.ComponentModel.ty8x74ifk3.wasm"
    },
    {
      "hash": "sha256-tqQewXl54QVjypNABL0mQZou4MaCG2QtIL/eCxHapvA=",
      "url": "_framework/System.Console.ipaqc4ly9h.wasm"
    },
    {
      "hash": "sha256-7iv3rRb6SZswpsN2vy+khdDhcT8fBXeEgADLXePXLcw=",
      "url": "_framework/System.Data.Common.meu4x66n48.wasm"
    },
    {
      "hash": "sha256-wFAsrNvmX0wIovecw3INJkK/SmkXtqL/WM06Ce+wjHg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.0ouyxo2hmc.wasm"
    },
    {
      "hash": "sha256-+sSo2WkfRpaOyC6S98doGle7YRgLaA2wv/vBZjEDyHw=",
      "url": "_framework/System.Diagnostics.TraceSource.ydx494s3qq.wasm"
    },
    {
      "hash": "sha256-1vzMD2gzMo9B2ZqsLLRz3WqsjFkqF27Mv7TPZVfYNBM=",
      "url": "_framework/System.Drawing.Primitives.60ppmnygmi.wasm"
    },
    {
      "hash": "sha256-wL9hReRO6JYKohMUiK0ts3ylL9+ypSji+KSFfJSuofA=",
      "url": "_framework/System.Drawing.wgem9d1jb2.wasm"
    },
    {
      "hash": "sha256-FBW6K4TORa24v2L639DPjf309NTGkrj0iIqiJaPqcYA=",
      "url": "_framework/System.IO.Pipelines.wn1erg3up3.wasm"
    },
    {
      "hash": "sha256-v6yI9YJeu4wXJxeNnLLJyllrpxYC64rsKUqSoHmjnJw=",
      "url": "_framework/System.Linq.Expressions.v0ag6cia2l.wasm"
    },
    {
      "hash": "sha256-Hu5vUxvACiris8IIEtS0TzbLqyZXI3m/ORSYGS13yqI=",
      "url": "_framework/System.Linq.e9ld198aq3.wasm"
    },
    {
      "hash": "sha256-RlfFVD8tmd886YxRB7kM4rQ7q6CR6pJdl7RbC+QmqlA=",
      "url": "_framework/System.Memory.y5rjb3vii6.wasm"
    },
    {
      "hash": "sha256-DBUmUjCWhQXA2oqjl0Ozb+wrIAe72A1ac7izJcsgHYc=",
      "url": "_framework/System.Net.Http.40bt2row14.wasm"
    },
    {
      "hash": "sha256-VsWTEOyEbltVNWebWtzswCEfVLEN7seHoNS6agRLaJw=",
      "url": "_framework/System.Net.Primitives.e24bsgwgy3.wasm"
    },
    {
      "hash": "sha256-1yAPtq9Y9SpkhQ1USxWVMh59yspawsHJVNuLp09NUlI=",
      "url": "_framework/System.ObjectModel.zdynnv896m.wasm"
    },
    {
      "hash": "sha256-82rTzefsr8AW2kCJPumuz/miIYXwHDPpqGxwRNCeyrM=",
      "url": "_framework/System.Private.CoreLib.jogawqraq5.wasm"
    },
    {
      "hash": "sha256-MBcDhxHkZI9ccNSSGsXCILHXS/NUqmuD8K3feJYuRqI=",
      "url": "_framework/System.Private.Uri.0gf0lphuvx.wasm"
    },
    {
      "hash": "sha256-GNh8YJjQ6M5TwhqxUSpP8rowvepqQo6N4wDUqJrDLU0=",
      "url": "_framework/System.Private.Xml.Linq.0y5cb1e798.wasm"
    },
    {
      "hash": "sha256-JFR+44dUD/7z5jnI+T8UaJdhh1H3qN7qw1smcR91zz4=",
      "url": "_framework/System.Private.Xml.otzakxycvw.wasm"
    },
    {
      "hash": "sha256-9DvWdzpd3IH/3qxlZrt/II73hAc9qP8eLb3/BtFXpfc=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.81uomoqhr0.wasm"
    },
    {
      "hash": "sha256-tKPShosI4XcMbhkya+09iy2wmfM0P2YP2SFUGXtNKog=",
      "url": "_framework/System.Reflection.Emit.Lightweight.83sei7lwgb.wasm"
    },
    {
      "hash": "sha256-AGiV5D0hD52zwyT0Qiv/2IzUuQCsjpV5q2cdQGUJK9Y=",
      "url": "_framework/System.Reflection.Primitives.kvhyhemwil.wasm"
    },
    {
      "hash": "sha256-dr2zPg+11BQOd27TZPxcs18PqUREGUfAtTD9nRdz7sw=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.it9v611w20.wasm"
    },
    {
      "hash": "sha256-sn3upz3jiKzzX0BWxHAEXHr2HWN94BM1A5jxiVBL/S4=",
      "url": "_framework/System.Runtime.InteropServices.qpr883temn.wasm"
    },
    {
      "hash": "sha256-rpFuNSjjLwdUgRpjAYvQvvDp7/5xe0gQJTmmJ6SHcp4=",
      "url": "_framework/System.Runtime.Numerics.27r0osoeod.wasm"
    },
    {
      "hash": "sha256-ydtKpAyL+cVC09VOfQOMSM3pfI3PJ27L8a367xhG144=",
      "url": "_framework/System.Runtime.Serialization.Formatters.drjzdg67ki.wasm"
    },
    {
      "hash": "sha256-yxmDLIilFRFGGh38YZy6oGeigTM2POb9etjyENeOCg0=",
      "url": "_framework/System.Runtime.Serialization.Primitives.nh506uwomz.wasm"
    },
    {
      "hash": "sha256-pTx/plyZbg9/RLo2HLysSXUZJpy+4LfQtfiwCM5427c=",
      "url": "_framework/System.Runtime.pvbaqupzrm.wasm"
    },
    {
      "hash": "sha256-iR1LDsrMu8+/lXc34fmnn4xNSPl2VcF55A5pGXpWSlw=",
      "url": "_framework/System.Security.Cryptography.3hl3rqf787.wasm"
    },
    {
      "hash": "sha256-5Y++7IQlv3nU8g6TlXnuAT7bUkdKlpQajNYc5312Yk8=",
      "url": "_framework/System.Text.Encoding.Extensions.75uivmr71p.wasm"
    },
    {
      "hash": "sha256-SQ1+aS+lCxp43qhvbxWS01rhQfbvNeDSN0xyk2P9/Hc=",
      "url": "_framework/System.Text.Encodings.Web.hq94nfnuw2.wasm"
    },
    {
      "hash": "sha256-mWijxlplKcB9legRt5DxT93bpfMbQh22UhJVBgQj9Eg=",
      "url": "_framework/System.Text.Json.xmy9dlnptx.wasm"
    },
    {
      "hash": "sha256-OViFI2C1pBjqYvQcfjrTXXSAFzUXWwHdN4MnUDCQ7b0=",
      "url": "_framework/System.Text.RegularExpressions.rr6ypy13yv.wasm"
    },
    {
      "hash": "sha256-7HRpxfGj5sI1zrphvqiLFIXmqbTPdY2VDAdJm1HCNIw=",
      "url": "_framework/System.Threading.k290n83y9v.wasm"
    },
    {
      "hash": "sha256-5claBNmyy8L12DFLS17Fh4SBiTjwhYts3ds7g8dX8Gc=",
      "url": "_framework/System.Xml.Linq.fnt4rzi185.wasm"
    },
    {
      "hash": "sha256-z6lJ2dLqjFO8i9yDuWV50JqG5CuDqO1ssAfKN80tAic=",
      "url": "_framework/System.Xml.ReaderWriter.1otkvd7d8u.wasm"
    },
    {
      "hash": "sha256-mO8Myb/YHsEXA9rrh5dZinveqXGkEbaG2JNi9ZpvjnY=",
      "url": "_framework/System.Xml.XDocument.ocxzop4g63.wasm"
    },
    {
      "hash": "sha256-p1SG2ibgNCMpayPPtA7y9LAS2esUkEydZJtxS5sc3Xs=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-N+/jRbIsqVbSKyrJpXTfko/MbGFn4mYhGgK+pW+zQ7o=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-wAf5wYdjHv/4ppKa7uJDvyNd3UldOBLEcWmqRq8IZZc=",
      "url": "_framework/dotnet.native.0s5gjpogh3.wasm"
    },
    {
      "hash": "sha256-XoX4c2LUiS5cCJhRPgapPU1Oc3ZmYKx6SEFmJ0SMjGY=",
      "url": "_framework/dotnet.native.qdj5gxypz1.js"
    },
    {
      "hash": "sha256-yfXUv1l/B489E8p12JxUvxly0JvHL9CCsoZUDlfGH9c=",
      "url": "_framework/dotnet.runtime.drv0pr9n5o.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-Ct142n5QK6Wm9/aPiH1SQ6boJ3kW2pxxsuaBLyQpugI=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-gBuYGrcWvTKHU4Jo7+JVNc1XP54Rv4WxJ3CHjfnqz+E=",
      "url": "index.html"
    },
    {
      "hash": "sha256-gm1avQAoeo72zVLUaCt2JIghAcuu4RHRBAbHvK5/1e8=",
      "url": "js/copy-functionality.js"
    },
    {
      "hash": "sha256-VOd0jE5WWzqpQjq4miUjONKHQxWt7cbBKJe0vNIMHnc=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-+3mLshcxmGlAzzqZUPvKOG4DYz6aRUl3Aecfm4fRMuo=",
      "url": "tailwindcss.3.4.16.js"
    }
  ]
};
